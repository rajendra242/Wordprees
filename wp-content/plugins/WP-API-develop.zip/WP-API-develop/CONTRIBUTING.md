# Contributing

Hi, and thanks for considering contributing! Before you do though, here's a few
notes on how best to contribute. Don't worry, I'll keep it short!

The WP REST API code now lives in core WordPress, so any contributions to the
API (**including new issues**) should be made via
[WordPress core Trac](https://core.trac.wordpress.org).

See also:
[Contributing to WordPress](https://codex.wordpress.org/Contributing_to_WordPress)
